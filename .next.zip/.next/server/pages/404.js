"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/404";
exports.ids = ["pages/404"];
exports.modules = {

/***/ "./pages/404.tsx":
/*!***********************!*\
  !*** ./pages/404.tsx ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nfunction PageNotFound() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"content-wrapper\",\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"section\", {\n            className: \"content-header\",\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    className: \"container-fluid\"\n                }, void 0, false, {\n                    fileName: \"E:\\\\paper-admin-develop\\\\paper-admin-develop\\\\pages\\\\404.tsx\",\n                    lineNumber: 6,\n                    columnNumber: 17\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"section\", {\n                    className: \"content\",\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        className: \"error-page\",\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            className: \"error-content\",\n                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h3\", {\n                                children: [\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"i\", {\n                                        className: \"fas fa-exclamation-triangle text-warning\"\n                                    }, void 0, false, {\n                                        fileName: \"E:\\\\paper-admin-develop\\\\paper-admin-develop\\\\pages\\\\404.tsx\",\n                                        lineNumber: 10,\n                                        columnNumber: 33\n                                    }, this),\n                                    \" Oops! Page not found.\"\n                                ]\n                            }, void 0, true, {\n                                fileName: \"E:\\\\paper-admin-develop\\\\paper-admin-develop\\\\pages\\\\404.tsx\",\n                                lineNumber: 10,\n                                columnNumber: 29\n                            }, this)\n                        }, void 0, false, {\n                            fileName: \"E:\\\\paper-admin-develop\\\\paper-admin-develop\\\\pages\\\\404.tsx\",\n                            lineNumber: 9,\n                            columnNumber: 25\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"E:\\\\paper-admin-develop\\\\paper-admin-develop\\\\pages\\\\404.tsx\",\n                        lineNumber: 8,\n                        columnNumber: 21\n                    }, this)\n                }, void 0, false, {\n                    fileName: \"E:\\\\paper-admin-develop\\\\paper-admin-develop\\\\pages\\\\404.tsx\",\n                    lineNumber: 7,\n                    columnNumber: 17\n                }, this)\n            ]\n        }, void 0, true, {\n            fileName: \"E:\\\\paper-admin-develop\\\\paper-admin-develop\\\\pages\\\\404.tsx\",\n            lineNumber: 5,\n            columnNumber: 13\n        }, this)\n    }, void 0, false, {\n        fileName: \"E:\\\\paper-admin-develop\\\\paper-admin-develop\\\\pages\\\\404.tsx\",\n        lineNumber: 4,\n        columnNumber: 9\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PageNotFound);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy80MDQudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFBO0FBQUEsU0FBU0EsWUFBWSxHQUFHO0lBRXBCLHFCQUNJLDhEQUFDQyxLQUFHO1FBQUNDLFNBQVMsRUFBQyxpQkFBaUI7a0JBQzVCLDRFQUFDQyxTQUFPO1lBQUNELFNBQVMsRUFBQyxnQkFBZ0I7OzhCQUMvQiw4REFBQ0QsS0FBRztvQkFBQ0MsU0FBUyxFQUFDLGlCQUFpQjs7Ozs7d0JBQU87OEJBQ3ZDLDhEQUFDQyxTQUFPO29CQUFDRCxTQUFTLEVBQUMsU0FBUzs4QkFDeEIsNEVBQUNELEtBQUc7d0JBQUNDLFNBQVMsRUFBQyxZQUFZO2tDQUN2Qiw0RUFBQ0QsS0FBRzs0QkFBQ0MsU0FBUyxFQUFDLGVBQWU7c0NBQzFCLDRFQUFDRSxJQUFFOztrREFBQyw4REFBQ0MsR0FBQzt3Q0FBQ0gsU0FBUyxFQUFDLDBDQUEwQzs7Ozs7NENBQUs7b0NBQUEsd0JBQXNCOzs7Ozs7b0NBQUs7Ozs7O2dDQUN6Rjs7Ozs7NEJBQ0o7Ozs7O3dCQUNBOzs7Ozs7Z0JBQ0o7Ozs7O1lBQ1IsQ0FDUjtDQUNMO0FBRUQsaUVBQWVGLFlBQVksRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL3BhZ2VzLzQwNC50c3g/Y2E2NyJdLCJzb3VyY2VzQ29udGVudCI6WyJmdW5jdGlvbiBQYWdlTm90Rm91bmQoKSB7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRlbnQtd3JhcHBlclwiPlxuICAgICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiY29udGVudC1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lci1mbHVpZFwiPjwvZGl2PlxuICAgICAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImNvbnRlbnRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlcnJvci1wYWdlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVycm9yLWNvbnRlbnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDM+PGkgY2xhc3NOYW1lPVwiZmFzIGZhLWV4Y2xhbWF0aW9uLXRyaWFuZ2xlIHRleHQtd2FybmluZ1wiPjwvaT4gT29wcyEgUGFnZSBub3QgZm91bmQuPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L3NlY3Rpb24+XG4gICAgICAgICAgICA8L3NlY3Rpb24+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IFBhZ2VOb3RGb3VuZDsiXSwibmFtZXMiOlsiUGFnZU5vdEZvdW5kIiwiZGl2IiwiY2xhc3NOYW1lIiwic2VjdGlvbiIsImgzIiwiaSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/404.tsx\n");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/404.tsx"));
module.exports = __webpack_exports__;

})();